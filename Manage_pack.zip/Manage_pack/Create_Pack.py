class creat():
    WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'manage')))).click()
    ic.get_url()
    WebDriverWait(self.driver, 30).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, config.get('ok', 'cr_ex')))).click()
    WebDriverWait(self.driver, 30).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, config.get('ok', 'sub_slt')))).click()
    WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'subject')))).click()
    WebDriverWait(self.driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, config.get('ok', 'pack_name')))).send_keys(config.get('ok', 'pack'))
    dt = WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'pack_desc'))))
    dt.click()
    time.sleep(5)
    dt.send_keys(config.get('ok', 'pack'))
    WebDriverWait(self.driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, config.get('ok', 'validity')))).send_keys(config.get('ok', 'days'))
    date = WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'date_box'))))
    date_value = "2022-05-22"
    self.driver.execute_script(f"arguments[0].value = '{date_value}';", date)
    time.sleep(3)
    WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'cr_pk')))).click()
    message_element = WebDriverWait(self.driver, 10).until(
        EC.visibility_of_element_located((By.XPATH, config.get('ok', 'cr_msg'))))
    message_text = message_element.text
    print("Text message displayed above okay_button:", message_text)
    WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'cr_pk')))).click()
    self.driver.save_screenshot("creat_s.png")
    okay_button = WebDriverWait(self.driver, 5).until(
        EC.visibility_of_element_located((By.CLASS_NAME, config.get('ok', 'okay'))))
    okay_button.click()
