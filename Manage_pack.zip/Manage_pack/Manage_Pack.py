import configparser
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import StaleElementReferenceException
import time
config = configparser.RawConfigParser()
config.read('my.properties')

def scroll(driver, by, value):
    element = WebDriverWait(driver, 60).until(EC.element_to_be_clickable((by, value)))
    actions = ActionChains(driver)
    actions.move_to_element(element)
    actions.perform()
class Manage_Pack:
    def get_url(self):
        elems = self.driver.find_elements(By.XPATH, "//a[@href]")
        for elem in elems:
            print(elem.get_attribute("href"))
        print('links')

    def __init__(self):
        self.service = Service(ChromeDriverManager().install())
        self.driver = webdriver.Chrome(service=self.service)
        self.driver.get(config.get('ok','url'))
        self.driver.maximize_window()

    def login(self):
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.ID,config.get('ok','un')))).send_keys(config.get('ok','user_name'))
        ic.get_url()
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.ID,config.get('ok','pw')))).send_keys(config.get('ok','password'))
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','login_bt')))).click()

    def Creat_Pack(self):
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','manage')))).click()
        ic.get_url()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR, config.get('ok','cr_ex')))).click()
        WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located((By.CSS_SELECTOR, config.get('ok','sub_slt')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH,config.get('ok','subject')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','pack_name')))).send_keys(config.get('ok','pack'))
        dt=WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','pack_desc'))))
        dt.click()
        time.sleep(5)
        dt.send_keys(config.get('ok','pack'))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','validity')))).send_keys(config.get('ok','days'))
        date=WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'date_box'))))
        date_value = config.get('ok','date')
        self.driver.execute_script(f"arguments[0].value = '{date_value}';", date)
        time.sleep(3)
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'cr_pk')))).click()
        message_element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH,config.get('ok','cr_msg'))))
        message_text = message_element.text
        print("Text message displayed above okay_button:", message_text)
        self.driver.save_screenshot("creat_s.png")
        okay_button = WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located((By.CLASS_NAME,config.get('ok','okay'))))
        okay_button.click()

    def Update_Pack(self):
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'manage')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR, config.get('ok', 'up_pk')))).click()
        WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located((By.CSS_SELECTOR, config.get('ok', 'sub_slt')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'subject')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'sub_sr')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'pk_sr')))).send_keys(config.get('ok','pacck'))
        #WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located((By.XPATH, config.get('ok', 'pk_na'))))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','edit')))).click()
        rnp=WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 're_na'))))
        rnp.send_keys((Keys.CONTROL + "a"))
        rnp.send_keys(Keys.DELETE)
        rnp.send_keys(config.get('ok','re_na_va'))
        dt = WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 're_pk_des'))))
        dt.send_keys((Keys.CONTROL + "a"))
        time.sleep(3)
        dt.clear()
        dt.send_keys(Keys.DELETE)
        dt.send_keys(config.get('ok','re_pk_dc'))
        red=WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 're_pk_val'))))
        red.send_keys((Keys.CONTROL + "a"))
        red.send_keys(Keys.DELETE)
        red.send_keys(config.get('ok','re_days'))
        date = WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'date_box'))))
        date.send_keys((Keys.CONTROL + "a"))
        date.send_keys(Keys.DELETE)
        date_value = config.get('ok','re_dt')
        self.driver.execute_script(f"arguments[0].value = '{date_value}';", date)
        time.sleep(3)
        WebDriverWait(self.driver,30).until((EC.element_to_be_clickable((By.XPATH,config.get('ok','Need_modification'))))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','make_available')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok','up_pk_bt')))).click()
        message_element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH, config.get('ok','up_msg'))))
        message_text = message_element.text
        print("Text message displayed above okay_button:", message_text)
        self.driver.save_screenshot("update_s.png")
        okay_button = WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located((By.CLASS_NAME, config.get('ok', 'okay'))))
        time.sleep(5)
        okay_button.click()




    def Assign_Pack(self):
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'manage')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR, config.get('ok', 'As_pk')))).click()
        WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located((By.CSS_SELECTOR, config.get('ok', 'sub_slt')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'subject')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'sub_sr')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'pk_sr')))).send_keys(config.get('ok', 'pacck'))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'edit')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'ex_na_sr')))).send_keys(config.get('ok','ex_name'))
        scroll(self.driver,By.XPATH,config.get('ok','View'))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'View')))).click()
        time.sleep(1)
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'pk_sr')))).send_keys(config.get('ok', 'Topic_name'))
        time.sleep(3)
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'Back')))).click()
        scroll(self.driver,By.XPATH,config.get('ok','check_box'))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'ex_na_sr')))).send_keys(config.get('ok', 'ex_name'))
        checkbox=WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'check_box'))))
        if not checkbox.is_selected():
            checkbox.click()
        scroll(self.driver,By.XPATH,config.get('ok','Assign_EXam'))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'Assign_EXam')))).click()
        message_element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH, config.get('ok', 'Assign_msg'))))
        message_text = message_element.text
        print("Text message displayed above okay_button:", message_text)
        self.driver.save_screenshot("Assign_s.png")
        okay_button = WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located((By.CLASS_NAME, config.get('ok', 'okay'))))
        time.sleep(5)
        okay_button.click()

    def View_Pack(self):
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'manage')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR, config.get('ok', 'vi_pk')))).click()
        WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located((By.CSS_SELECTOR, config.get('ok', 'sub_slt')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'subject')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'sub_sr')))).click()
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'pk_sr')))).send_keys(config.get('ok', 'pacck'))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'View')))).click()
        scroll(self.driver, By.XPATH, config.get('ok', 'rows'))
        WebDriverWait(self.driver, 30).until(EC.element_to_be_clickable((By.XPATH, config.get('ok', 'add_exam')))).send_keys(config.get('ok', 'ex_name'))
        time.sleep(5)








if __name__ == "__main__":
    ic=Manage_Pack()
    ic.login()
    #ic.Creat_Pack()
    #ic.Update_Pack()
    #ic.Assign_Pack()
    ic.View_Pack()






